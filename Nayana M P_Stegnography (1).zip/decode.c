/*
Name        : NAYANNA M P
*/
#include <stdio.h>
#include "decode.h"
#include "types.h"
#include "common.h"
#include <string.h>
#include <stdlib.h>

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Stego Image file, Output Text file 
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */

Status open_decode_files(DecodeInfo *decInfo)
{
      // Stego Image file
      decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
      // Do Error handling
      if (decInfo->fptr_stego_image == NULL)
      {
          perror("fopen");
          fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);
  
          return e_failure;
      }
  
      // Output Text File
     decInfo->fptr_output = fopen(decInfo->output_fname, "w");
     // Do Error handling
      if (decInfo->fptr_output == NULL)
      {
          perror("fopen");
          fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_fname);
  
          return e_failure;
      }
  
      // No failure return e_success
      return e_success;
 }
//Read and validate command line arguments
Status read_and_validate_decode_args(char*argv[], DecodeInfo *decInfo)
 {

      char* temp = strstr( argv[2], ".bmp");
      if(temp == NULL)
          return e_failure;
      else
          decInfo->stego_image_fname = argv[2]; 
           
      if(argv[3] != NULL)
      {
          decInfo->output_fname = argv[3];
      }
      else
      {
         decInfo->output_fname = "Output.txt";
      }
     
     return e_success;
}
//decode num from image 
Status decode_num_from_img(char* buffer, FILE* fptr)
{
    int value = 0;
    for(int i = 0; i < 32; i++)
    {
	if( buffer[i] & 1)
	    value |= 1 << (31 - i);
    }
    return value;
}
//decode byte to lsb
Status decode_byte_to_lsb(char *data_buffer)
{
    char data=0;
    int count=7;
    for(int i=0;i<8;i++)
    {
	if(data_buffer[i]&1)
	    data=data|1<<count;
	count--;
    }
    return data;
	
}
//decode data from image
Status decode_data_from_image(char* data, int size, FILE* fptr_stego_image)
{
    int i=0;
    char arr[8];
    for(i=0;i<size;i++)
    {
	fread(arr,8,1,fptr_stego_image);
	data[i]=decode_byte_to_lsb(arr);
    }	
    data[i]=0;

    return e_success;	
}
//decose magic string
Status decode_magic_string(const char* magic_string, DecodeInfo *decInfo)
{
        char data[3];
	fseek(decInfo->fptr_stego_image,54,SEEK_SET);
	decode_data_from_image(data, strlen(magic_string), decInfo->fptr_stego_image);
    	return e_success;
}
// decode secret file extension size
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
	char image_buffer[32];
	fread(image_buffer, sizeof(int), 8, decInfo->fptr_stego_image);
	decInfo->output_file_extn_size = decode_num_from_img(image_buffer, decInfo->fptr_stego_image);
	return e_success;
}
//decode secret file extension 
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo)
{
    file_extn=malloc(decInfo->output_file_extn_size+1);
    decode_data_from_image(file_extn,decInfo->output_file_extn_size,decInfo->fptr_stego_image);
    return e_success;
}
//decode secret file size
Status decode_secret_file_size(long *file_size, DecodeInfo *decInfo)
{	
	char image_buffer[32];
	fread(image_buffer, sizeof(int), 8, decInfo->fptr_stego_image);
	*file_size  = decode_num_from_img(image_buffer, decInfo->fptr_stego_image);
	return e_success;
}
//decode secret file data
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    	rewind(decInfo->fptr_output);
	char ch;
	char arr[8];
	for (int i = 0; i < decInfo->output_file_size; i++)
	{
	    fread(arr, sizeof(char), 8, decInfo->fptr_stego_image);
	    ch=decode_byte_to_lsb(arr);
	    fwrite(&ch, sizeof(char), 1, decInfo->fptr_output);
	}
	return e_success;		    
}

/* Main Decoding Function*/
Status do_decoding(DecodeInfo *decInfo)
{
   printf("INFO: ## Decoding Procedure Started ##\n");
   if(!open_decode_files(decInfo))                                //check if all files are opened
   {
	printf("INFO: Open_Decode_Files SUCCESS\n");

	if (!decode_magic_string(MAGIC_STRING, decInfo))        //check if decode magic string retuens success or not
	{
	    printf("INFO: MAGIC_STRING Decode SUCCESS\n");

	    if (!decode_secret_file_extn_size(decInfo))         //check secret file extension size
	    {
		printf("INFO: Secret file extension size Decoded\n");

		if (!decode_secret_file_extn( decInfo->output_file_extn, decInfo))
		{
		    printf("INFO: Secret file extension Decoded\n");

		    if (!decode_secret_file_size(&decInfo->output_file_size, decInfo))       //to check secret file size
		    {
			printf("INFO: Secret file size Decoded\n");     

			if (!decode_secret_file_data(decInfo))
			{
			    printf("INFO: Secret file data Decoded\n");
			    printf("INFO: ## Decoding Done Successfully ##\n");
			}
			else
			    printf("Secret File Data Decode Failure\n");
		    }
                    else
			printf("Secret File Size Decode Failure\n");
		}
		else
		    printf("Secret File Extension Decode Failure\n");
	    }
	    else
		printf("Secret File Extension Size Decode Failure\n");
	
	}
	else
	    printf("MAGIC_STRING Decode Failure\n");  
    }
   else
       printf("open_decode_files FAILURE\n");
}

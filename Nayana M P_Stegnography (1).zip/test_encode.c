#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

int main( int argc,char *argv[])
{
        if(check_operation_type(argv) == e_encode)
        {
            EncodeInfo encInfo;
            printf("We are going to perform Encode operation\n");
            if(read_and_validate_encode_args(argv,&encInfo) ==e_success)
            {
                printf("Read and validation for encode is completed\n");
                if(do_encoding(&encInfo) == e_success)
                {
                    printf("Encoding is Completed\n");
                }
            }
        }
   
	else if(check_operation_type(argv)==e_decode)
	{
	    DecodeInfo decInfo;
	    printf("We are going to perform decode operation\n");
	    if(read_and_validate_decode_args(argv,&decInfo)==e_success)
	    {
		printf("Read and validation for decode is completed\n");
		if(do_decoding(&decInfo)==e_success)
		{
		    printf("INFO:## Decoding Done Successfully ##\n");
		}
	    }
	}
	return 0;
    }


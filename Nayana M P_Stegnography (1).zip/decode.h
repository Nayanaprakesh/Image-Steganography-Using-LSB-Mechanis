#ifndef DECODE_H
#define DECODE_H
#include<stdio.h>

#include "types.h" // Contains user defined types

/* 
 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
    /* Source Image info */
    char *output_file_extn;
    FILE *fptr_src_image;
    uint image_capacity;
    long output_file_size;
    char image_data[MAX_IMAGE_BUF_SIZE];

    /* Secret File Info */
    char *output_fname;
    FILE *fptr_output;
    char extn_secret_file[MAX_FILE_SUFFIX];
    char secret_data[MAX_SECRET_BUF_SIZE];
    long output_file_extn_size;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

} DecodeInfo;


/* Encoding function prototype */
/*Get file pointers from i/p and o/p files */
Status open_decode_files(DecodeInfo *decInfo);

/*Perform decoding*/
Status do_decoding(DecodeInfo *decInfo);

/*Decode secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo);

/*Decode secret file size*/
Status decode_secret_file_size(long *file_size, DecodeInfo *decInfo);

/*Decode secret file extension*/
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo);

/*Decode secret file extension size*/
Status decode_secret_file_extn_size(DecodeInfo *decInfo);

/*Decode magic string*/
Status decode_magic_string(const char* magic_string, DecodeInfo *decInfo);

/*Decode data from image*/
Status decode_data_from_image(char* data, int size, FILE* fptr_stego_image);

/*Decode byte to lsb*/
Status decode_byte_to_lsb(char *data_buffer);

/*Decode num from image*/
Status decode_num_from_img(char* buffer, FILE* fptr);

/*Read and validate command line argument*/
Status read_and_validate_decode_args(char*argv[], DecodeInfo *decInfo);
#endif
